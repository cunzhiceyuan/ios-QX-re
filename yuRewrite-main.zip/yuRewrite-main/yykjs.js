/*
音乐壳教室

付费课程及全部资料

[rewrite_local]

https://api.agency.immusician.com url script-response-body https://raw.githubusercontent.com/Yu9191/Rewrite/main/yykjs.js

[mitm]
hostname = api.agency.immusician.com
*/

有本事自己写
