使用说明：解锁会员权限,过期完整版视频,如果你觉得获取视频打扰到您,您可以手动屏蔽这条重写！原视频解锁可以试看85%

[rewrite_local]

#完整视频
https://(?:\w+\.)?xlzhao\.com/.*\.(?:m3u8|mp3) url script-request-header https://raw.githubusercontent.com/Yu9191/Rewrite/main/m3u8/xiongmaoboshibaike.js

[mitm] 

hostname = *.xlzhao.com