
/*

name：夏时国际VPN
to：https://t.cn/A60vysg2
me：@ios151 Thank@zhangpeifu
Ts：Borrowing @zhangpeifu's script


[rewrite_local]
^https?:\/\/(\w+\.com|198\.18\.76\.\d+)\/addressx5\/* url script-response-body https://raw.githubusercontent.com/Yu9191/Rewrite/main/Surgexiashivpn.js
^https?:\/\/googleads\.g\.doubleclick-cn\.net\/* url reject

[MITM]
hostname = \w+\.com, 198\.18\.76\.\d+,googleads.g.doubleclick-cn.net

*/

var version_='jsjiami.com.v7';var z=b;(function(c,d,e,f,g,h,i){return c=c>>0x4,h='hs',i='hs',function(j,k,l,m,n){var y=b;m='tfi',h=m+h,n='up',i+=n,h=l(h),i=l(i),l=0x0;var o=j();while(!![]&&--f+k){try{m=-parseInt(y(0x193,'g!zQ'))/0x1+-parseInt(y(0x19c,'[R!1'))/0x2*(-parseInt(y(0x1a0,'4J)]'))/0x3)+parseInt(y(0x1ac,'Za]2'))/0x4*(parseInt(y(0x192,'tw@$'))/0x5)+parseInt(y(0x19e,'tw@$'))/0x6*(-parseInt(y(0x1a5,'qmsM'))/0x7)+parseInt(y(0x197,'6Yue'))/0x8*(-parseInt(y(0x1ab,'0!z2'))/0x9)+-parseInt(y(0x1ad,'oXW3'))/0xa*(-parseInt(y(0x195,'qmsM'))/0xb)+-parseInt(y(0x1a4,'(H]l'))/0xc*(-parseInt(y(0x1a7,'0!z2'))/0xd);}catch(p){m=l;}finally{n=o[h]();if(c<=f)l?g?m=n:g=n:l=n;else{if(l==g['replace'](/[UeQLGAwlSMxTynCHbqR=]/g,'')){if(m===k){o['un'+h](n);break;}o[i](n);}}}}}(e,d,function(j,k,l,m,n,o,p){return k='\x73\x70\x6c\x69\x74',j=arguments[0x0],j=j[k](''),l='\x72\x65\x76\x65\x72\x73\x65',j=j[l]('\x76'),m='\x6a\x6f\x69\x6e',(0x136386,j[m](''));});}(0xc50,0x68db0,a,0xc7),a)&&(version_=a);function b(c,d){var e=a();return b=function(f,g){f=f-0x192;var h=e[f];if(b['HypptE']===undefined){var i=function(n){var o='abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=';var p='',q='';for(var r=0x0,s,t,u=0x0;t=n['charAt'](u++);~t&&(s=r%0x4?s*0x40+t:t,r++%0x4)?p+=String['fromCharCode'](0xff&s>>(-0x2*r&0x6)):0x0){t=o['indexOf'](t);}for(var v=0x0,w=p['length'];v<w;v++){q+='%'+('00'+p['charCodeAt'](v)['toString'](0x10))['slice'](-0x2);}return decodeURIComponent(q);};var m=function(n,o){var p=[],q=0x0,r,t='';n=i(n);var u;for(u=0x0;u<0x100;u++){p[u]=u;}for(u=0x0;u<0x100;u++){q=(q+p[u]+o['charCodeAt'](u%o['length']))%0x100,r=p[u],p[u]=p[q],p[q]=r;}u=0x0,q=0x0;for(var v=0x0;v<n['length'];v++){u=(u+0x1)%0x100,q=(q+p[u])%0x100,r=p[u],p[u]=p[q],p[q]=r,t+=String['fromCharCode'](n['charCodeAt'](v)^p[(p[u]+p[q])%0x100]);}return t;};b['PnLwSJ']=m,c=arguments,b['HypptE']=!![];}var j=e[0x0],k=f+j,l=c[k];return!l?(b['IHSZxu']===undefined&&(b['IHSZxu']=!![]),h=b['PnLwSJ'](h,g),c[k]=h):h=l,h;},b(c,d);}function a(){var A=(function(){return[version_,'QjASMsQAyjxiaLmGiRq.AcUxowmTle.Slve7bHnC==','WQNcTCoN','vsy3uGrRW64cpYxdMhO','W6pcUCoRWR/dJSopWR4','WPpcPaNcTefqksvoBG','WRxcJhDJnmoUWQ8w','F8oTp8kdBCkIsSonba','AqT5W4xdTHnTWQWqW6xdKSkZWQC','WRldI8o4WQddRbWGFmo/WR7cUmo8','W7nJE3OUm8kijmkXdCooWRG'].concat((function(){return['WRpdKCkAs2OSW4NdIwC','W7ZcKmoXvSkmnSoyW4xdTa','W5NcSfu0WOdcIq','omkaWQSzWOxcPZa','tmojbmkK','lvW8WPVcRKqW','W6WpWOPwW75ZWQ3cHa','WPdcL8oNWPKHWQhdLtauW4jgpcy','xc0XuGDQW7CCcX/dMwy','WOZcKaS','W4/cTXjKW4BdRCovlW'].concat((function(){return['omowB8kc','W5hdJLPRh8k7W59zEYC','pSonWQ8iW6FdVeb8z8kd','W4NcSLWIW6RdRmoYjehdSG','omohWQb0W43dMgHRwW','iCo3WOFdI8kNifrk','W7ZcLmoXlCkSeCo/W6hdOJ4','W7TBamk8yZ7dGCkWcmkhCCo/'];}()));}()));}());a=function(){return A;};return a();};typeof $httpClient!==z(0x19d,'pX3D')?('undefined'!==typeof $response['body']?body=$response[z(0x1a1,'Gs2Q')][z(0x1a2,'8GLE')](/(v.*?i.*?p.*?[^1]+)1([^,]+),/g,z(0x19f,'0!z2')):body=$response[z(0x1a8,'Z7s)')],console[z(0x194,'KZPD')](body),$done({'body':body})):console[z(0x1a6,'hYGI')]('该代码需要在Surge中运行。');var version_ = 'jsjiami.com.v7';
