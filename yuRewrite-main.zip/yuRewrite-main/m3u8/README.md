# 瑟瑟视频获取

脚本仅测试91短视频：https://ba65.eimkeb.com
## 脚本注明

1. 记得打开代理软件的通知权限
2. 播放地址域名随时变化,记得自己替换
3. 感谢原作者yuheng,Evn..等

## 脚本描述

- 本脚本为瑟瑟视频获取脚本,可获取瑟瑟视频的播放地址,跳转到浏览器或者其他工具即可观看
- 本脚本为个人学习使用,请勿用于商业用途

## 使用方法

- 打开`重写规则`➟ 打开`91短视频（举例）`➟ 通知然后点击跳转➟ 点击`获取视频地址`➟ 跳转到浏览器或者其他工具即可观看

## 最新播放地址
2024.1.4 正则：^https:\/\/[^\/]*\.pnowdvc\.cn\/\w+\/[a-z0-9]{32}\/[a-z0-9]{32}\.m3u8 


2024.1.10 正则：^https:\/\/[^\/]*\.xgfipub\.cn\/\w+\/[a-z0-9]{32}\/[a-z0-9]{32}\.m3u8 

> [Quantumult X](https://raw.githubusercontent.com/Yu9191/Rewrite/main/m3u8/m3u8.conf)

> [suger](https://raw.githubusercontent.com/Yu9191/Rewrite/main/m3u8/m3u8.sgmodule)

> [其他代理工具请用ScriptHub转换](https://github.com/Script-Hub-Org/Script-Hub)



## 自己更新域名

- 打开quantumultx抓包 然后 打开瑟瑟视频app 然后找到包含m3u8的链接 然后复制域名替换即可
- 不是适用于所有瑟瑟视频app的域名,请自行测试


## 瑟瑟地址（个别失效）

*缅北禁地  https://ac9d.wykfnp.com
暗网解密  https://714.ndqvyg.com
51吃瓜Pro  https://3d4f.knjbzw.com
51猎奇  https://088f.bjzezy.com
私房ktv  https://89.rwhmcn.com
天涯社区  https://f3d.wchgdn.com
黑洞社区  https://ca64.mdplzw.com
暗网禁区  https://0b.yrhwse.com
她趣  https://5e7.rtlzhe.com
Blued  https://5ba.aryhca.com
妹团  https://36.paxvrh.com
杏吧  https://9923.hzbwia.com
老九品茶  https://0a.obntac.com
微密圈  https://a4.henwap.com
海角乱伦社区  https://f58d.ipqjlb.com
51动漫  https://75.luduwz.com
蜜豆视频  https://6de.scrrzr.com
黑料天堂  https://42fa.jaedlj.com
51吃瓜  https://lz7as.zzttja.com
新版滴滴  https://cf.sjlqjh.com
七度少女  https://11a.uvmtsn.com
91妻友  https://08c0.lvxpha.com
91制片厂Pro  https://baf.dhlwyz.com
抖阴Proj  https://6f7s.pbgrzh.com
果冻传媒APP  https://07.npcwwc.com
福利姬  https://9f.gectab.com
91fans  https://fc.zlnkbn.com
pilipili(二次元)  https://747.jkhpmy.com
歪歪视频  https://c8.qznpyr.com
GTV  https://958.xqhjej.com
91视频-全能版  https://fbrg.rzvwcq.com
撸先生  https://01f4.czhxnw.com
成人B站  https://d4.qhzvgn.com
小蓝俱乐部  https://ca.sbnyxu.com
50度灰  https://od5em.smpaqa.com
51品茶  https://f5f.vavkyj.com
蚂蚁翻墙  https://636d.obqyyh.com
91短视频  https://66.kccber.com
91AV  https://ca7.rahzss.com
快手  https://eb81.nnjzpw.com
汤头条  https://a3ou.cxuvtk.com

