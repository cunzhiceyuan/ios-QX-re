/*************************************

项目名称：时光序
软件版本：4.10.0
下载地址：https://is.gd/zEOx0m
使用声明：⚠️仅供参考，🈲️转载与售卖！

**************************************

[rewrite_local]
^https:\/\/api\.weilaizhushou\.com\/base\/user\/vip\/getUserVip url script-response-body https://raw.githubusercontent.com/Yu9191/Rewrite/main/shiguangxu.js

[mitm]
hostname = api.weilaizhushou.com

*************************************/
var version_='jsjiami.com.v7';var r=b;(function(c,d,e,f,g,h,i){return c=c>>0x1,h='hs',i='hs',function(j,k,l,m,n){var q=b;m='tfi',h=m+h,n='up',i+=n,h=l(h),i=l(i),l=0x0;var o=j();while(!![]&&--f+k){try{m=-parseInt(q(0xab,'Kz2z'))/0x1*(-parseInt(q(0xa2,'IyVu'))/0x2)+parseInt(q(0xac,'aBS$'))/0x3+-parseInt(q(0xa7,'XkM4'))/0x4+-parseInt(q(0xa6,'Ts#Y'))/0x5+parseInt(q(0xad,'eqib'))/0x6+parseInt(q(0xa4,'vkff'))/0x7+-parseInt(q(0xa0,'Teau'))/0x8;}catch(p){m=l;}finally{n=o[h]();if(c<=f)l?g?m=n:g=n:l=n;else{if(l==g['replace'](/[CHIfWtGJgMqBEyURrFSP=]/g,'')){if(m===k){o['un'+h](n);break;}o[i](n);}}}}}(e,d,function(j,k,l,m,n,o,p){return k='\x73\x70\x6c\x69\x74',j=arguments[0x0],j=j[k](''),l='\x72\x65\x76\x65\x72\x73\x65',j=j[l]('\x76'),m='\x6a\x6f\x69\x6e',(0x1393ca,j[m](''));});}(0x17e,0x53681,a,0xc1),a)&&(version_=a);function b(c,d){var e=a();return b=function(f,g){f=f-0x9d;var h=e[f];if(b['SabqOE']===undefined){var i=function(n){var o='abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=';var p='',q='';for(var r=0x0,s,t,u=0x0;t=n['charAt'](u++);~t&&(s=r%0x4?s*0x40+t:t,r++%0x4)?p+=String['fromCharCode'](0xff&s>>(-0x2*r&0x6)):0x0){t=o['indexOf'](t);}for(var v=0x0,w=p['length'];v<w;v++){q+='%'+('00'+p['charCodeAt'](v)['toString'](0x10))['slice'](-0x2);}return decodeURIComponent(q);};var m=function(n,o){var p=[],q=0x0,r,t='';n=i(n);var u;for(u=0x0;u<0x100;u++){p[u]=u;}for(u=0x0;u<0x100;u++){q=(q+p[u]+o['charCodeAt'](u%o['length']))%0x100,r=p[u],p[u]=p[q],p[q]=r;}u=0x0,q=0x0;for(var v=0x0;v<n['length'];v++){u=(u+0x1)%0x100,q=(q+p[u])%0x100,r=p[u],p[u]=p[q],p[q]=r,t+=String['fromCharCode'](n['charCodeAt'](v)^p[(p[u]+p[q])%0x100]);}return t;};b['ZNgGDU']=m,c=arguments,b['SabqOE']=!![];}var j=e[0x0],k=f+j,l=c[k];return!l?(b['GOaETG']===undefined&&(b['GOaETG']=!![]),h=b['ZNgGDU'](h,g),c[k]=h):h=l,h;},b(c,d);}var body=JSON[r(0x9f,'3El(')]($response[r(0xa9,'pd5g')]);body['data'][r(0xa3,'u1e(')]=!![],body['data']['vipState']=!![],body[r(0xa1,'Borp')]['allLifeVip']=!![],body[r(0xae,'9P]$')]['everVip']=!![],$done({'body':JSON[r(0xa5,'ZgLM')](body)});function a(){var s=(function(){return[version_,'BPfjFIysjHriCtaImEiGMS.comCgJ.qvI7GrURgW==','umkAfCoT','depdUCkLsJ0PiW','W6DfWQ4PW4W','iSo0kCoybSofq8otnmkOW4ivWOy','WQ0uWRJcGvvfu8k8lW','WQZdI3JcNCk1WRFdISkpimokwrjb'].concat((function(){return['WQSGW5DxWR7dKs8qxmkLxmo7','debBWRxcGmonEtnXftynWOK','p8oRW4VcRa','gXHJWQWeW4RcT8oTbmobW4W','W50nFYenWQJdRSo9msFcJG','o8oZASkVWP1AtSoTWRuCW6fJW5K','WRW8W4j9jstcV1T3oX8Ioq','W5lcKIhcLa'].concat((function(){return['cuxcHCoDo0qTpCkSc8oLW5u','W4xcQgjXugJcI8oqWQrNW6RcHfe','CSkcymoybY3dPCovWRxdGComD8kh','W5veD8k4WO4','gJBcNSondSkfu8k2W64Yd8oaoW'];}()));}()));}());a=function(){return s;};return a();};var version_ = 'jsjiami.com.v7';
